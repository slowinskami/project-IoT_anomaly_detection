#!/bin/bash

#bash pythonscript_airodump.bash
bash pythonscript_arpspoof-injection.bash
bash pythonscript_arpspoof-passive.bash
#bash pythonscript_deauth-all.bash
#bash pythonscript_deauth.bash
bash pythonscript_dos1.bash
bash pythonscript_dos2.bash
bash pythonscript_dos3.bash
bash pythonscript_iot-toolkit.bash
bash pythonscript_nmap.bash
bash pythonscript_nmap.bash