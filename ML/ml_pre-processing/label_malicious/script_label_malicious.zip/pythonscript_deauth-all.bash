#!/bin/bash
numberOfFiles=$(ls -1q ./malicious_deauth-all/*.pdml | wc -l)
count=1
for file in ./malicious_deauth-all/*.pdml
do
  ((count++))
  python2.7 pdml2arff_malicious_deauth.py "$file"
  echo -n "$((${count}*100/${numberOfFiles} | bc)) %     "
  echo -n R | tr 'R' '\r'
  sleep 2
done
